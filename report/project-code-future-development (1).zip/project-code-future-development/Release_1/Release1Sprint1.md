# Release Backlog - for release due 050218

Scrum master - Kira, rotation after first sprint

## First Release Functionality
In the first released version of the software, the user will be able to:

+ Request for a model to be trained
+ Predict a value based on a trained model and some data
+ Check if the training is finished (on reserve)

### First Sprint Backlog (090118 - 160118)
In the first sprint following will be implemented for the above user stories.
Weights are set by individual members accordingly.

+ Define an abstract class Algorithm - Tom Oliver, Tom He
+ Naive Bayes algorithm - Tom Oliver
+ SVM - James
+ Random forests - Kira
+ Cox regression - Victor
+ Kaplan-meier - Victor
+ K-fold verification - Tom He
+ Feature-importance curve - Roy
+ ROC curve - Kira
+ Precision specificity curve - James

Issues added 100118
+ Design a test class - Tom He
+ Create an abstract "Regression" class - Victor
+ Create an abstract "Classifier" class - Kira

Issues added 120118
+ Conduct data preprocessing/cleaning - Tom Oliver

### Sprint 1 - Stand-up Meeting 1 - online 100118

+ New issues are added as outlined above for class structure: dividing
classification and regression algorithms
+ K-fold cross validation is to be combined into abstract class Algorithm
+ ROC curve is to be combined into abstract class Classifier

### Sprint 1 - Stand-up Meeting 2 - online 120118
Design decisions and updates:

+ Issues on Tom He to be postponed for future sprints 
  due to difficulty in access from abroad
+ "Regression" and "Classifier" classes are made, algorithms 
  extend these as subclasses accordingly
+ ROC curve as a separate module, RandomForest and SVM 
  will divided for classification and regression

### Sprint 1 - Stand-up Meeting 3 - online 150118
Design decisions and updates:

+ Remove RegressionAlgorithm wrapper around regression algorithms
  and inherit directly from Algorithm, which will remove redundancy
+ Design Test Class issue is removed from current sprint
