# Third Sprint Backlog (24012018 - 29012018)

Scrum master - Roy

## Retrospective Meeting
The following points are made during retrospective meeting prior to the next sprint planning:

+ improved in terms of code checking and planning class structure
+ generally good in accommodating modified code to work
+ last remaining issues will be finished on 230118 before the start of the next Sprint


## Tasks for the Third Sprint:
The following tasks are agreed to be assigned in this sprint. Weights are set during the planning.

* Basic string data pre-processing and unit tests on these in Data - Tom (4)
* Build basic get status and server improvement - Roy (3)
* Integrate Cox and Kaplan Meier plots in server - Victor (3)
* Build test requests - Victor (4)
including test cases such as :
    * 1) Algorithms/data file do not exist - not found error
    * 2) k fold value is out of range/invalid - should be at least 2
* Modify SVC - James (2)
* Add Random Forest Tree visualisation method - Kira (2)
* Write test for ROC in multiclass setting - Kira (3)

### Notes:
+ Potentially arrange retrospective meeting 300118 and design doc write-up Meeting
+ Arrange supervisor meeting in Week 1

+ remaining issues from Sprint 2 is added to Sprint 3, due to difficulty faced
in handling imports under the current hierarchy structure (adding algorithms to server issue)
+ CI continued

### Sprint 3 - Stand up Meeting 1 260118
+ server should also include options for algorithms without k value for regression
Algorithms
+ import issues currently resolved
+ in terms of completeness, some issues are mostly finished but left unclosed for
review

Updates:
+ Team meeting to be on Monday 29th
+ Supervisor meeting arranged to be on Tuesday 30th

### Retrospective Meeting
+ Code reviews are great! Comment other people's commits to make sure your opinion of their code is heard.
+ Comment your code.
+ To test the correctness of the algorithms we could ask the product owner for example inputs and outputs.

### Sprint 3 - Extended sprint cycle for first release
There have been two issues to worked on in the preparation of the first release. 
These are uploaded on sprint 3 milestone and end date is extended.
+ CI along with working test suite for demo - including refinements in Tests.py
+ Get status method

Updates:
Since Supervisor meeting on 30/Jan, team has been working on the above two issues 
and report to be handed in.

