
//Response to a query asking possible tests that are available given specific training data and an expected output

Recommend_algorithmn_response(file, input columns, output column){

•Determine_al()


•Send_al()


}

//Response to a query to create a model using a certain test and specific training data

Train_response(file, input columns, output column, type of test, k fold value){

•Get_model()


◦Yes - done


◦No


◾Get_input_data()


◾Split_data_k_fold()


◾Depending on type of test: call relevant algorithm method call


◾Save_model()


◾Done


•Send_status() //possible method to send status to HCI?


}

//Response to a query for a certain model with some data to get a predicted result back

Predict_response(file, input, columns, output column, type of test, k fold value){

•Get_model()


◦Yes


◾Predict_value()


◦No


◾Get_input_data()


◾Split_data_k_fold()


◾Depending on type of test: call relevant algorithm method call


◾Predict_value()


◾Save_model()


}

//Response to a query checking if the model has been finished training

Check_if_finished_response(){}



//Response to a query commanding to stop training the model

Terminate_response(){}



Methods

•Determine_al(): method that determines type of algorithms available for particular data


◦Input - file, input columns, output column


◦Body


◦Output - list of strings/ identifiable tags for tests


•Send_al(): method that calls determine_al() and returns output as JSON format


◦Input - void


◦Body - call determine_al(), create JSON, send to HCI


◦Output - void/ success




•Get_model(): method that sends GET api call to BE of a model to check if model exists


◦Input - file, input columns, output column, type of test, k fold value


◦Body - sends api call with following input to check if model exists


◦Output


◾Null (- call method train)


◾Compressed model returned , decompress


•Get_input_data(): method that sends GET api call to BE to fetch columns


◦Input - file, input columns, output column


◦Body - make api call to BE with input variables, read in csv as matrix/ format applicable for training


◦Output - data stored in suitable format


•*Split_data_k_fold(): method that accepts raw data and divides to training and test sets


◦Input- k,  data stored in suitable format, from get_input_data()


◦Body -


◦Output - return X train, X test, Y train, Y test


◾*for multi input columns?


•Do_naive_bayes(): method that creates model with naive bayes


◦Input - output from split_data_k_fold()


◦Body - do naive bayes


◦*Output - pickled saved format


•Do_svm(): method that creates model trained with support vector machine


◦Input - output from split_data_k_fold()


◦Body - do svm


◦Output - pickled saved format


•Do_random_forests(): method that creates model trained with random forests


◦Input -


◦Body -


◦Output - pickled saved format


•Get_feature_importance_plot(): method accepts random forest model extracts data points


◦Input - random forest model


◦Body - use input model to generate plot, extract data points to be saved in BE


◦Output - list of consisting of x-y data


•Get_roc_curve(): method that plots roc curve on a given model and returns as image file


◦Input - model classifier, data required


◦Body - plot roc curve, save as image file


◦Output - image file


•Get_pre_spe_curve(): method that plots precision and specificity curve on a given model and returns as image file


◦Input - model classifier, data required


◦Body - plot curve and save a image file


◦Output - image file


•Get_statistics(): method that computes statistical summary on the model trained


◦Input - model trained


◦Body - mean, variance etc should be found


◦Output - summary of statistics, csv


•Save_model(): method that makes POST api call to BE to store model


◦Input


◦Body


◦Output - void/status




•Do_cox_regression()


•Do_kaplan_meier()




•Predit_value(): method that predicts value using given model and input


◦Input - model , input


◦Body


◦Output - output value






Points of discussion

1.Response to train_reponse(): need to notify HCI success of failure?


2.Save_model(): save just pickled model or send multiple files to save to BE including:


1.Statistics - csv


2.ROC, precision and specificity curves - image


3.Predicted output


3.Image analysis

4.Data cleaning? not all data will be suitable for trainig straight away so some pre proccessing may be requried.
