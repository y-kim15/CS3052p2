# Second Sprint Backlog (16012018 - 23012018)

Scrum master - Victor

## Retrospective Analysis
The following points were made about the previous sprint during the scrum meeting:

+ It would have been good to dedicate more time beforehand to planning of the class structure,
since we had to improvise a little with it.
+ Despite having to improvise aspects of the class structure during the sprint, the team handled
the unexpected obstacle well.
+ It is essential to check that the code runs before pushing!

## Tasks for the Second Sprint:
The following list of tasks has been compiled and assigned for the second sprint. For this
sprint, we have set the weights together instead of setting them individually.

+ Statistics on trained model other than score (mean and variance) - Kira
+ Test suite - Tom
+ Server/RESTful API - Roy
+ Once the server is done, add the calls to the individual algorithms to it - everyone
+ Finish Specificity Precision Curves - James
+ Adjust the implementations of algorithms that depend on the "lifelines" library to fit the
class structure followed by the other algorithms - Victor
+ Continuous Integration - Victor

### NB for now we are assuming that the data is received as part of the RESTful request

### Sprint 2 - Stand-up Meeting 1 180118
+ Note current server design will follow the design of HCL -> BE -> ML
Hence, data is received with the training/predict request from BE

### Sprint 2 - Stand-up Meeting 2 200118
+ There was confusion over the format the server sends the input data in. It has
been decided that the input data is part of the json struct, with the necessary
columns selected in the input\_columns and output\_columns.


### Sprint 2 - Stand-up Meeting  3 220118
+ THe directory that contains the code for the algorithms should be moved into the directory
containing the server code since the latter needs to be able to import the former.
