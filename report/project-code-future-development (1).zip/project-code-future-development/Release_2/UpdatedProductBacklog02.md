### Product Backlog For Extensions
This following new user stories have been included for the extended specification:

+ The user can choose to pre-process data using different scalars before model training.
+ The user can split a dataset into a training set and a test set. The test set will be used to make predictions   on the model. The user can define the proportions of the split or use default values otherwise.
+ The user can choose feature selection in the model construction.
+ The user can define hyper-parameter values on which to build a model. The model will be built with default optimal values otherwise.
+ The user can choose to build a model under fixed values of False Negative Rate or True Positive Rate as preferred.
+ The user can specify the number of runs to obtained a trained model.
+ The user can use Kaplan Meier plots to obtain corrected p values.

Not all the above user stories have been implemented for the second release since
they will be addressed in the final release after going through team collaboration and integration.
