#Second Sprint Backlog (21022018-04032018)

Scrum master - Tom He

## Retrospective Analysis:
The following points were made about the previous sprint during the scrum meeting:
+ It would be good to start inter group collaboration especially with the back-end group
+ Ensure the branches are used reasonably with discreet merge actions

## Tasks for the Second Sprint:
The following list of tasks has been compiled and assigned for the second sprint. For this sprint, we have reassigned some uncompleted issues from last sprint.

+ Create port for data request - Roy
+ Extend the CI Suite - Victor
+ Implement Estimator Selection/Suggestion - Tom He
+ Adapt the Server to the Defined API - Tom, Roy
+ Implement Stopping the Training - Tom
+ Implement extra features suitable for the extension - James
+ Adapt the Server to the pipelines - Tom, Roy
+ Modify and refine data cleaning step - Kira

### Sprint 2 - Stand-up Meeting 1  22022018
+ Dicussed about the structure of Data.py file and the corresponding data preprocessing such as scaling.


### Sprint 2 - Stand-up Meeting 2/Supervisor Meeting 29022018
+ Clarified the major structure of a desired report which will mainly focus on the SCRUM process.
+ Agreed on seeking further collaboration with HCI team and made contact with one HCI team

## Extra Minutes:
+ Spoken to Oggie and have received some advice for the extension requirements
+ James, who was responsible designing the pipeline processing method, has updated other members
+ Informed to the server side, Tom and Roy, about the information we will receive from the user should extension is implemented
+ Consistent issues have risen that the standard API designed for the year group is limited such as
	○ Start training does not include details of user options such as: 
        - option to divide data to training and testing, 
        - option to set hyper-parameters to be used, 
        - option to do pre-processing steps
	○ Specifying column type for input data 
		§ Categories such as discrete, continuous, and string are convenient for implementation but not useful for data cleaning process
		§ Requirement is that it should handle ordinal, nominal data
+ Suggestion to design two separate APIs, one for standard and another for the extended version including Peter's requirement
	
Attended Year group meeting with Peter, some new functionalities he has mentioned are:
+ Using Kaplan Meier curves to find corrected p values and 
+ Retrieving values from confusion matrices
+ The user should also be able to specify the number of runs to be done on a model training

### Sprint 2 - Stand-up Meeting 3 02032018
+ Discusssed the approaches to track the progress in pipeline operations.
+ Had inter-group discussion with a back-end team and reached the agreement on developing a new API for extension.
Considerations for new API include: more flags for data,suitable columns selection for Cox Regression, hyperparameters for tuning specific estimators.

## Extra Minutes:
+ Described what we do on ML side, how we want the current protocol to be modified
+ Agreed for future meetings of three groups for collaboration
+ ML server can ask the backend to pass specified input and output columns required for training, rather than just CSV file, meaning formatting should be done in ML side 
    (this might not be defined in the current Backend protocol but can be implemented in BE side)
+ Also, it will be possible to specify specific rows (samples)

