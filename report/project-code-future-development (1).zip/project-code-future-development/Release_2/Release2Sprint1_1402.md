# Release Backlog - for release due 050318

## Second Release Functionality
Functionality and maintenance planned for the second release:

+ Adaptation to the now-created app-wide API
+ Authentication against the backend
+ Cooperation with other groups
+ Creation of a more sophisticated training termination procedure
+ Extension and optimisation of CI
+ Implementation of automatic selection of hyper-parameters
+ Estimators/Algorithms suggestion
+ Better visualization of lifetime analysis
+ Integration of getStatus in the algorithm classes
+ Model meta-data
+ Data pre-processing

### Sprint Backlog 2.1 (140218 - 200218)
Scrum master - James

Issues:

+ Adaptation to the API - Roy, Tom Oliver
+ Cancel training procedure - Tom Oliver
+ Extension and optimisation of CI - Victor
+ Automatic selection of hyper-parameters - Tom He
+ Estimator/Algorithm selection - Tom He
+ Data pre-processing - James
+ Changing the test values to those specified by the stake-holder - Kira


Issues added 160218:

+ Implement pipelines for data processing - James

### Sprint 1 - Stand-up Meeting 1 - online 150218

+ Our model fitting is wrong, we haven't been training on all the data
+ Changes needed to how we calculate values for ROC and PR curves
+ We are going to set up our own docker images

### Sprint 1 - Stand-up Meeting 2 - online 160218

+ We are going to implement Pipelines to guarentee preprocessing
+ New fitting design will break getStatus
+ Changes to how we select columns for training
+ Whole new plan in how to process data and calculate k fold statistics using pipelines and gridsearchcv
+ New branch to work on setting up pipelines while others continue to work on development
+ Changes to the init method for algorithms

### Sprint 1 - Stand-up Meeting 3 - online 180218

+ Possible protocol improvement suggestions
+ Discussion on how user specified parameters are to be handled

### Retrospective

+ There was a rather large change to the layout of the alorithm classes. Additionally there was large change on to how data will be processed, allowing users to input both preprocessing and hyperparameters
+ We have more ideas for the user input to allow them to specifiy a pipeline with hyperparameters at all stages but without more information on the extended spec we are unable to move ahead with it
+ There was good progress on a all other aspects of the project, data cleaning was slightly improved, the server is almost fully changed to intergroup api and CI is running with a much improved checking time
+ In terms of the issues, we have finished all of the above (or in the case of the API, we are adapting as we get more information)
+ An important aim for near future sprints is to intergrate with a backend and possibly a HCI group
+ Once we receive the extended spec we plan to update the data process to its final version
