#!/usr/bin/env bash

cd venv

virtualenv-3.6 .python

source .python/bin/activate

pip3 install -r dependencies.txt
