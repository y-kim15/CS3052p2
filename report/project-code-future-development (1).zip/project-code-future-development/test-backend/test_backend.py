import uuid
import pandas

from flask import Flask, send_file, request, json

app = Flask(__name__)

ninth_meta = {
    'file_path': '9',
    'file_name': 'pred.csv',
    'id': '9',
    'supported_views': {
        'raw': {
            'size': 13431
        }
    },
    'type': 'tabular',
    'status': 'uploading'
}

eighth_meta = {
    'file_path': '8',
    'file_name': 'newData.csv',
    'id': '8',
    'supported_views': {
        'raw': {
            'size': 13431
        }
    },
    'type': 'tabular',
    'status': 'uploading'
}

seven_meta = {
    'file_path': '7',
    'file_name': 'multiTarget.csv',
    'id': '7',
    'supported_views': {
        'raw': {
            'size': 13431
        }
    },
    'type': 'tabular',
    'status': 'uploading'
}

sixth_meta = {
    'file_path': '6',
    'file_name': 'continTarget.csv',
    'id': '6',
    'supported_views': {
        'raw': {
            'size': 13431
        }
    },
    'type': 'tabular',
    'status': 'uploading'
}

snd_meta = {
    'file_path': '2',
    'file_name': 'coxregTarget.csv',
    'id': '2',
    'supported_views': {
        'raw': {
            'size': 13431
        }
    },
    'type': 'tabular',
    'status': 'uploading'
}

fst_meta = {
    'file_path': '1',
    'file_name': 'binaryTarget.csv',
    'id': '1',
    'supported_views': {
        'raw': {
            'size': 13431
        }
    },
    'type': 'tabular',
    'status': 'uploading'
}

trd_meta = {
    'file_path': '3',
    'file_name': 'RCCHEcombinedRawdataForRanalysis.csv'
}

fth_meta = {
    'file_path': '4',
    'file_name': 'ZeissValidationSetCollatedDataPDC.csv'
}

fifth_meta = {
    'file_path': '5',
    'file_name': 'model'
}

fst_files = {
    '1': fst_meta,
    '2': snd_meta,
    '3': trd_meta,
    '4': fth_meta,
    '5': fifth_meta,
    '6': sixth_meta,
    '7': seven_meta,
    '8': eighth_meta,
    '9': ninth_meta
}

projects = {
    'project1': {
        'project_name': 'project1',
        'files': fst_files
    }
}

file_id_with_path = {}


@app.route('/JH-Project/ML7-Test-Backend/current_user', methods=['GET'])
def current_user():
    try:
        if request.headers['Authorization'] != 'Bearer 12345':
            return 'Not Authorised', 401
    except KeyError:
        return 'Not Authorised', 401
    return json.dumps({
        "username": 'ml7',
        "privileges": [],
        "projects": [{
            "project_name": "project1",
            "access_level": ""
        }]
    })


@app.route('/JH-Project/ML7-Test-Backend/projects/<project_name>/files_by_id/<id>', methods=['GET'])
def file_by_id(project_name, id):
    try:
        if request.headers['Authorization'] != 'Bearer 12345':
            return 'Not Authorised!', 401
    except KeyError:
        return 'Not Authorised!', 401
    if project_name not in projects:
        return 'Project not found', 404
    files = projects[project_name]['files']
    if id not in files:
        if id not in file_id_with_path:
            return 'File not found', 404
    params = request.args
    if not params or not params['view'] or params['view'] == 'meta':
        return json.jsonify(files[id]), 200
    elif params['view'] == 'raw':
        print(id)
        return send_file(file_id_with_path[id], mimetype='application/octet-stream'), 200
    elif params['view'] == 'tabular':
        if params['cols']:
            cols = list(map(int, eval(params['cols'])))
            data = pandas.read_csv(files[id]['file_name'], usecols=cols)
            print(data)
            data.to_csv("temp", index=False)
            return send_file("temp", mimetype='text/csv'), 200
        else:
            send_file(files[id]['file_name'], mimetype='text/csv'), 200
    else:
        return 'Unneeded Parameter(s)', 400


@app.route('/JH-Project/ML7-Test-Backend/projects/<project_name>/files_by_id/<id>', methods=['POST'])
def upload_by_id(project_name, id):
    try:
        if request.headers['Authorization'] != 'Bearer 12345':
            return 'Not Authorised!', 401
    except KeyError:
        return 'Not Authosied!', 401
    if project_name not in projects:
        return 'Not Found', 404
    return 204


@app.route('/JH-Project/ML7-Test-Backend/projects/<project_name>/files/<path:path>', methods=['POST'])
def file_upload(project_name, path):
    try:
        if request.headers['Authorization'] != 'Bearer 12345':
            return 'Not Authorised!', 401
    except KeyError:
        return 'Not Authorised!', 401
    path = '/{}'.format(path)
    if project_name not in projects:
        return 'Project not found', 404
    try:
        open(path)
        return 'File already exist', 400
    except FileNotFoundError:
        params = request.args
        if not params or params['action'] == 'upload':
            try:
                with open(path, 'wb') as f:
                    f.write(request.data)
            except FileNotFoundError:
                return 'Path given doesn\'t have a valid parent directory', 400
            file_id = str(uuid.uuid4())
            file_id_with_path[file_id] = path
            return json.jsonify({
                'id': file_id,
                'created': True
            })
        else:
            return 'Bad Request', 400
    except IsADirectoryError:
        return 'File already exist', 400
    except NotADirectoryError:
        return 'Path given doesn\'t have a valid parent directory', 400


@app.route('/JH-Project/ML7-Test-Backend/projects/<project_name>', methods=['GET'])
def project_info(project_name):
    try:
        if request.headers['Authorization'] != 'Bearer 12345':
            return 'Not Authorised!', 401
    except KeyError:
        return 'Not Authorised!', 401
    if project_name not in projects:
        return 'Project not found', 404
    return json.jsonify(projects[project_name]), 200


@app.route('/JH-Project/ML7-Test-Backend/projects', methods=['GET'])
def projects_info():
    try:
        if request.headers['Authorization'] != 'Bearer 12345':
            return 'Not Authorised!', 401
    except KeyError:
        return 'Not Authorised!', 401
    return json.jsonify(list(projects.values())), 200


if __name__ == '__main__':
    app.run(port=8100)
