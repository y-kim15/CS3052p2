## README

### The protocol followed to design the server can be found at:
https://github.com/CS3099JH2017/cs3099jh/blob/master/protocols/ML01.md

### The following processes are tested on the school lab machine
##### To setup the virtual environment:

cd venv

virtualenv-3.6 .python

source .python/bin/activate

pip3 install -r dependencies.txt

##### NB:
If the previous command produces an error of "unable to find module numpy", run

pip3 install numpy

and then re-run

pip3 install -r dependencies.txt

##### After setting up the virtual environment
##### To run the unit tests:

cd src

python3 tests.py

The following command line arguments can be used:

--roc  -> View ROC curves

--conf -> View confusion matrix

--prc  -> View Precision recall curves

--feat -> View feature plots for random forests

--tree -> Generates and saves an image representing each tree in the random forest. Images will be saved in src/server/plots

--pred -> View plot of expected against actual values for regression algorithms

--kpln -> View plot of hazard function

--cox  -> View plot of the baseline hazard function

--display -> View all plots

for example:

python3 tests.py --roc

If a specific algorithm is to be run it can be passed as a parameter as seen below:

python3 tests.py SVCBinaryTest --prc

###### To run the API tests:

cd venv

source .python/bin/activate

./run-server

In another terminal:

cd venv

./run-test-backend

In a third terminal:

cd tests

npm install

npm test


###### To run the server from venv

./run-server.sh

###### We have built a simple backend server for testing purpose only.
###### To run the test backend server from venv:

./run-test-backend.sh

###### After finishing executing the servers, you can run from venv:

./kill-server.sh

to close all processes in a clean way.

##### To create and use neural networks for data analysis
You need a machine that has a Nvidia GPU and cuda installed

Put your training and validation images in the folder /venv/testData/NeuralNetworkData/train/ and /venv/testData/NeuralNetworkData/valid/ 

Install the fastai library using 
pip install https://github.com/fastai/fastai/archive/master.zip

You may also have you run 
pip install torch

You can then run a script like the one at /venv/src/image_analysis_test.py
Editing the file used for prediction as necessary 

