(function() {
    var url = "http://localhost:8080/JH-Project/machine-learning-api/1.0";

    classifierTypes = ["discrete", "discrete", "discrete", "discrete", "discrete", "discrete", 
                    "discrete", "discrete", "continuous", "discrete"];
    continTypes = ["discrete", "discrete", "discrete", "discrete", "discrete", "discrete", 
                "discrete", "discrete", "discrete", "continuous"];
    coxregTypes = ["discrete", "continuous", "continuous", "continuous", "continuous", 
                "continuous", "continuous", "continuous", "continuous", "continuous", 
                    "continuous", "continuous"];
    classifierColumns = [];
    continColumns = [];
    coxregColumns = [];
    for (var i = 0; i < classifierTypes.length - 1; i++) {
        classifierColumns.push({
            "column_index": i,
            "column_type": classifierTypes[i]
        });
    }
    for (var i = 0; i < continTypes.length - 1; i++) {
        continColumns.push({
            "column_index": i,
            "column_type": continTypes[i]
        });
    }
    for (var i = 0; i < coxregTypes.length; i++) {
        coxregColumns.push({
            "column_index": i,
            "column_type": coxregTypes[i]
        });
    }

    function isDiscreteTarget(algorithm_name) {
        algorithms = [
            "Gaussian naive bayes",
            "Bernoulli naive bayes",
            "Multinomial naive bayes",
            "random forest classifier",
            "svc"
        ];
        return algorithms.indexOf(algorithm_name) >= 0;
    }

    function isContinuousTarget(algorithm_name) {
        algorithms = [
            "random forest regressor",
            "svr"
        ];
        return algorithms.indexOf(algorithm_name) >= 0;
    }

    function isLifetimeRegressionTarget(algorithm_name) {
        algorithms = [
            "cox regression"
        ];
        return algorithms.indexOf(algorithm_name) >= 0;
    }

    function wrap(type, job_id) {
        var data = {
            "job_id": job_id,
            "training_data": {
                "id": "",
                "project_name": "project1"
            },
            "output_directory_path": "/var/tmp",
            "input_columns": [],
            "output_columns": []
        }
        switch (type) {
            case "discrete":
                data.training_data.id = "1";
                data.input_columns = classifierColumns;
                data.output_columns.push({
                    "column_index": classifierTypes.length - 1,
                    "column_type": classifierTypes[classifierTypes.length - 1]
                });
                break;
            case "continuous":
                data.training_data.id = "6";
                data.input_columns = continColumns;
                data.output_columns.push({
                    "column_index": continTypes.length - 1,
                    "column_type": continTypes[continTypes.length - 1]
                });
                break;
            case "lifetime":
                data.training_data.id = "2";
                data.input_columns = coxregColumns;
                data.output_columns.push({
                    "column_index": coxregTypes.length - 1,
                    "column_type": coxregTypes[coxregTypes.length - 1]
                });
                break;
        }
        request_obj = {
            url: url + "/models",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer 12345"
            },
            body: JSON.stringify(data)
        };
        return new Promise(function (resolve) {
            request.post(request_obj, function(err, response, body) {
                expect(response.statusCode, body).to.equal(201);
                resolve();
            });
        });
    }

    module.exports = {
        url: url,
        classifierTypes: classifierTypes,
        continTypes: continTypes,
        coxregTypes, coxregTypes,
        classifierColumns: classifierColumns,
        continColumns: continColumns,
        coxregColumns: coxregColumns,
        isDiscreteTarget: isDiscreteTarget,
        isContinuousTarget: isContinuousTarget,
        isLifetimeRegressionTarget: isLifetimeRegressionTarget,
        wrap: wrap
    }

})();
