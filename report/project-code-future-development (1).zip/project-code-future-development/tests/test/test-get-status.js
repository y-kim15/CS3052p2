var expect = require("chai").expect;
var request = require("request");
var util = require("../util");

describe("get status of training", function() {
    var model_id;

    before((done) => {
        request(util.url + "/jobs", (err1, response1, body1) => {
            if (err1) done(err1);
            var job_id;
            body1 = JSON.parse(body1);
            for (var i = 0; i < body1.data.jobs.length; i++) {
                if (body1.data.jobs[i].algorithm_name === "Gaussian naive bayes") {
                    job_id = body1.data.jobs[i].job_id;
                    break;
                }
            }
            var data = {
                "job_id": job_id,
                "training_data": {
                    "id": "1",
                    "project_name": "project1"
                },
                "output_directory_path": "/var/tmp",
                "input_columns": classifierColumns,
                "output_columns":[{
                    "column_index": classifierTypes.length - 1,
                    "column_type": classifierTypes[classifierTypes.length - 1]
                }]
            };
            request_obj = {
                url: util.url + "/models",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer 12345"
                },
                body: JSON.stringify(data)
            };
            request.post(request_obj, (err2, response2, body2) => {
                if (err2) done (err2);
                expect(response2.statusCode).to.equal(201);
                body2 = JSON.parse(body2);
                model_id = body2.data.model_id;
                done();
            });
        });
    });

    it("can check the status of training", (done) => {
        request_obj = {
            url: util.url + "/models/project1/" + model_id,
            headers: {
                "Authorization": "Bearer 12345"
            }
        }
        request(request_obj, (err, response, body) => {
            if (err) done(err);
            expect(response.statusCode).to.equal(200);
            body = JSON.parse(body);
            expect(body.data.percent_trained).to.be.a("number");
            expect(body.data.status).to.be.a("string");
            expect(body.data.description).to.be.a("string");
            expect(body.data.job_id).to.be.a("string");
            expect(body.data.model_id).to.be.a("string");
            expect(body.data.start_time).to.be.a("string");
            expect(body.data.started_by).to.be.a("string");
            done();
        });
    });

    it("refuses a request without necessary permission", (done) => {
        request_obj = {
            url: util.url + "/models/project1/" + model_id,
            headers: {
                "Authorization": "Unauthorized"
            }
        }
        request(request_obj, (err, response, body) => {
            if (err) done(err);
            expect(response.statusCode).to.equal(401);
            body = JSON.parse(body);
            expect(body.error).to.be.a("string");
            expect(body.error_description).to.be.a("string");
            expect(body.user_message).to.be.a("string");
            done();
        });
    });

    it("refuses a request with a non-existent model id", (done) => {
        request_obj = {
            url: util.url + "/models/project1/not_a_model_id",
            headers: {
                "Authorization": "Bearer 12345"
            }
        }
        request(request_obj, (err, response, body) => {
            if (err) done(err);
            expect(response.statusCode).to.equal(404);
            body = JSON.parse(body);
            expect(body.error).to.be.a("string");
            expect(body.error_description).to.be.a("string");
            expect(body.user_message).to.be.a("string");
            done();
        });
    });
});
