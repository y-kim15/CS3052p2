var expect = require("chai").expect;
var request = require("request");
var util = require("../util");

dataTypes = ["continuous", "continuous", "discrete", "discrete", "discrete", "discrete",
              "date", "discrete", "discrete", "discrete", "discrete", "discrete", "discrete"];
predTypes = ["continuous", "continuous", "discrete", "discrete", "discrete", "discrete",
              "date", "discrete", "discrete", "discrete", "discrete", "discrete"];
dataColumns = [];
predColumns = [];
for (var i = 0; i < dataTypes.length - 1; i++) {
    dataColumns.push({
        "column_index": i,
        "column_type": dataTypes[i]
    });
}
for (var i = 0; i < predTypes.length - 1; i++) {
    predColumns.push({
        "column_index": i,
        "column_type": predTypes[i]
    });
}

describe("get prediction", () => {
    var model_id;

    before((done) => {
        request(util.url + "/jobs", (err1, response1, body1) => {
            if (err1) done(err1);
            var job_id;
            body1 = JSON.parse(body1);
            for (var i = 0; i < body1.data.jobs.length; i++) {
                if (body1.data.jobs[i].algorithm_name === "Gaussian naive bayes") {
                    job_id = body1.data.jobs[i].job_id;
                    break;
                }
            }
            var data = {
                "job_id": job_id,
                "training_data": {
                    "id": "1",
                    "project_name": "project1"
                },
                "output_directory_path": "/var/tmp",
                "input_columns": [
                {
                    "column_index": 0,
                    "column_type": "discrete"
                },
                {
                    "column_index": 1,
                    "column_type": "discrete"
                },
                {
                    "column_index": 3,
                    "column_type": "discrete"
                },
                {
                    "column_index": 4,
                    "column_type": "discrete"
                },
                {
                    "column_index": 5,
                    "column_type": "discrete"
                },
                {
                    "column_index": 6,
                    "column_type": "discrete"
                },
                {
                    "column_index": 7,
                    "column_type": "discrete"
                },
                {
                    "column_index": 8,
                    "column_type": "discrete"
                },
                {
                    "column_index": 9,
                    "column_type": "discrete"
                }
                ],
                "output_columns": [
                {
                    "column_index": 2,
                    "column_type": "discrete"
                }
                ]
            }
            request_obj = {
                url: util.url + "/models",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer 12345"
                },
                body: JSON.stringify(data)
            };
            request.post(request_obj, (err2, response2, body2) => {
                if (err2) done(err2);
                expect(response2.statusCode).to.equal(201);
                body2 = JSON.parse(body2);
                model_id = body2.data.model_id;
                done();
            });
        });
    });

    it("can get a prediction based on a model and some input", (done) => {
        data = {
            "data_file": {
                "id": "1",
                "project_name": "project1"
            },
            "input_columns": [
            {
                "column_index": 0,
                "column_type": "discrete"
            },
            {
                "column_index": 1,
                "column_type": "discrete"
            },
            {
                "column_index": 3,
                "column_type": "discrete"
            },
            {
                "column_index": 4,
                "column_type": "discrete"
            },
            {
                "column_index": 5,
                "column_type": "discrete"
            },
            {
                "column_index": 6,
                "column_type": "discrete"
            },
            {
                "column_index": 7,
                "column_type": "discrete"
            },
            {
                "column_index": 8,
                "column_type": "discrete"
            },
            {
                "column_index": 9,
                "column_type": "discrete"
            }
            ]
        }
        request_obj = {
            url: util.url + "/models/prediction/project1/" + model_id,
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer 12345"
            },
            body: JSON.stringify(data)
        };
        request.post(request_obj, (err, response, body) => {
            if (err) done(err);
            console.log(body);
            expect(response.statusCode).to.equal(200);
            body = JSON.parse(body);
            expect(body.data.result_type).to.be.a("string");
            expect(body.data.results).to.be.an("array");
            for (var i = 0; i < body.data.results.length; i++) {
                expect(body.data.results[i]).to.be.a("number");
            }
            done();
        });
    });

    it("refuses a request with a model that does not exist", (done) => {
        data = {
            "data_file": {
                "id": "1",
                "project_name": "project1"
            },
            "input_columns": classifierColumns
        }
        request_obj = {
            url: util.url + "/models/prediction/project1/not_a_model_id",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer 12345"
            },
            body: JSON.stringify(data)
        };
        request.post(request_obj, (err, response, body) => {
            if (err) done(err);
            expect(response.statusCode).to.equal(404);
            body = JSON.parse(body);
            expect(body.error).to.be.a("string");
            expect(body.error_description).to.be.a("string");
            expect(body.user_message).to.be.a("string");
            done();
        });
    });
});
