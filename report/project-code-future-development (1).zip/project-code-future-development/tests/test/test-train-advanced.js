var expect = require("chai").expect;
var request = require("request");
var util = require("../util");

describe("request to train a pipeline", () => {
    var transformers;
    var estimators;

    before((done) => {
        request(util.url + "/transformers", (err1, response1, body1) => {
            if (err1) done(err1);
            transformers = JSON.parse(body1).data.jobs;
            
            request(util.url + "/estimators", (err2, response2, body2) => {
                if (err2) done(err2);
                estimators = JSON.parse(body2).data.jobs;
                done();
            });
        });
    });

    it("can start every pipeline with one transformer", (done) => {
        done();
    });
});
