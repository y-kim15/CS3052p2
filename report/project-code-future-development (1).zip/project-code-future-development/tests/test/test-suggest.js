var expect = require("chai").expect;
var request = require("request");
var util = require("../util");

describe("get algorithm suggestion", () => {
    it("can suggest an optimal algorithm for some data", (done) => {
        data = {
            "training_data": {
                "id": "1",
                "project_name": "project1"
            },
            "input_columns": classifierColumns,
            "output_columns": [{
                "column_index": classifierTypes.length - 1,
                "column_type": classifierTypes[classifierTypes.length - 1]
            }]
        }
        request_obj = {
            url: util.url + "/suggest",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer 12345"
            },
            body: JSON.stringify(data)
        }
        request.post(request_obj, (err, respone, body) => {
            if (err) done(err);
            expect(respone.statusCode).to.equal(200);
            body = JSON.parse(body);
            expect(body.data.jobs).to.be.an("array");
            for (var i = 0; i < body.data.jobs.length; i++) {
                expect(body.data.jobs[i].job.job_id).to.be.a("string");
                expect(body.data.jobs[i].job.data_type).to.be.a("string");
                expect(body.data.jobs[i].job.algorithm_name).to.be.a("string");
                expect(body.data.jobs[i].job.partial_training_support).to.be.a("boolean");
                expect(body.data.jobs[i].job.job_description).to.be.a("string");
                expect(body.data.jobs[i].job.parameters).to.be.an("array");
                for (var j = 0; j < body.data.jobs[i].job.parameters.length; j++) {
                    expect(body.data.jobs[i].job.parameters[j].id).to.be.a("string");
                    expect(body.data.jobs[i].job.parameters[j].required).to.be.a("boolean");
                    expect(body.data.jobs[i].job.parameters[j].type).to.be.a("string");
                    expect(body.data.jobs[i].job.parameters[j].description).to.be.a("string");
                }
                expect(body.data.jobs[i].score).to.be.a("number");
            }
            done();
        });
    });

    it("denies a request without authorization", (done) => {
        data = {
            "training_data": {
                "id": "1",
                "project_name": "project1"
            },
            "input_columns": classifierColumns,
            "output_columns": [{
                "column_index": classifierTypes.length - 1,
                "column_type": classifierTypes[classifierTypes.length - 1]
            }]
        }
        request_obj = {
            url: util.url + "/suggest",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Unauthorized"
            },
            body: JSON.stringify(data)
        }
        request.post(request_obj, (err, respone, body) => {
            if (err) done(err);
            expect(respone.statusCode).to.equal(401);
            body = JSON.parse(body);
            expect(body.error).to.be.a("string");
            expect(body.error_description).to.be.a("string");
            expect(body.user_message).to.be.a("string");
            done();
        });
    });

    it("denies a request without input columns", (done) => {
        data = {
            "training_data": {
                "id": "1",
                "project_name": "project1"
            },
            "output_columns": [{
                "column_index": classifierTypes.length - 1,
                "column_type": classifierTypes[classifierTypes.length - 1]
            }]
        }
        request_obj = {
            url: util.url + "/suggest",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer 12345"
            },
            body: JSON.stringify(data)
        }
        request.post(request_obj, (err, respone, body) => {
            if (err) done(err);
            expect(respone.statusCode).to.equal(400);
            body = JSON.parse(body);
            expect(body.detail).to.be.a("string");
            expect(body.status).to.be.a("number");
            expect(body.title).to.be.a("string");
            expect(body.type).to.be.an("string");
            done();
        });
    });

    it("denies a request without output columns", (done) => {
        data = {
            "training_data": {
                "id": "1",
                "project_name": "project1"
            },
            "input_columns": classifierColumns
        }
        request_obj = {
            url: util.url + "/suggest",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer 12345"
            },
            body: JSON.stringify(data)
        }
        request.post(request_obj, (err, respone, body) => {
            if (err) done(err);
            expect(respone.statusCode).to.equal(400);
            body = JSON.parse(body);
            expect(body.detail).to.be.a("string");
            expect(body.status).to.be.a("number");
            expect(body.title).to.be.a("string");
            expect(body.type).to.be.an("string");
            done();
        });
    });

    it("denies a request without training data", (done) => {
        data = {
            "input_columns": classifierColumns,
            "output_columns": [{
                "column_index": classifierTypes.length - 1,
                "column_type": classifierTypes[classifierTypes.length - 1]
            }]
        };
        request_obj = {
            url: util.url + "/suggest",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer 12345"
            },
            body: JSON.stringify(data)
        }
        request.post(request_obj, (err, respone, body) => {
            if (err) done(err);
            expect(respone.statusCode).to.equal(400);
            body = JSON.parse(body);
            expect(body.detail).to.be.a("string");
            expect(body.status).to.be.a("number");
            expect(body.title).to.be.a("string");
            expect(body.type).to.be.an("string");
            done();
        });
    });
});
