var expect = require("chai").expect;
var request = require("request");
var util = require("../util");

describe("get models in a project", () => {
    before((done) => {
        request(util.url + "/jobs", (err1, response1, body1) => {
            if (err1) done(err1);
            var data = {
                "job_id": JSON.parse(body1).data.jobs[0].job_id,
                "training_data": {
                    "id": "1",
                    "project_name": "project1"
                },
                "output_directory_path": "/var/tmp",
                "input_columns": classifierColumns,
                "output_columns":[{
                    "column_index": classifierTypes.length - 1,
                    "column_type": classifierTypes[classifierTypes.length - 1]
                }]
            };
            request_obj = {
                url: util.url + "/models",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer 12345"
                },
                body: JSON.stringify(data)
            };
            request.post(request_obj, (err2, response2, body2) => {
                if (err2) done(err2);
                done();
            });
        });
    });

    it("can return a list of of models inside a given project", (done) => {
        request_obj = {
            url: util.url + "/models/project1",
            headers: {
                "Authorization": "Bearer 12345"
            }
        }
        request(request_obj, (err, response, body) => {
            if (err) done(err);
            expect(response.statusCode).to.equal(200);
            body = JSON.parse(body);
            expect(body.data).to.be.an("array");
            for (var i = 0; i < body.data.length; i++) {
                expect(body.data[i].percent_trained).to.be.a("number");
                expect(body.data[i].status).to.be.a("string");
                expect(body.data[i].description).to.be.a("string");
                expect(body.data[i].job_id).to.be.a("string");
                expect(body.data[i].model_id).to.be.a("string");
                expect(body.data[i].start_time).to.be.a("string");
                expect(body.data[i].started_by).to.be.a("string");
            }
            done();
        });
    });

    it("denies a request without the necessary authorization", (done) => {
        request_obj = {
            url: util.url + "/models/project1",
            headers: {
                "Authorization": "Unauthorized"
            }
        }
        request(request_obj, (err, response, body) => {
            if (err) done(err);
            expect(response.statusCode).to.equal(401);
            body = JSON.parse(body);
            expect(body.error).to.be.a("string");
            expect(body.error_description).to.be.a("string");
            expect(body.user_message).to.be.a("string");
            done();
        });
    });

    it("denies a request for a non-existent project", (done) => {
        request_obj = {
            url: util.url + "/models/not_a_project",
            headers: {
                "Authorization": "Bearer 12345"
            }
        }
        request(request_obj, (err, response, body) => {
            if (err) done(err);
            expect(response.statusCode).to.equal(404);
            body = JSON.parse(body);
            expect(body.error).to.be.a("string");
            expect(body.error_description).to.be.a("string");
            expect(body.user_message).to.be.a("string");
            done();
        });
    });
});
