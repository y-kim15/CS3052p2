var expect = require("chai").expect;
var request = require("request");
var util = require("../util");

describe("start training a machine learning model", function() {
    var jobs;

    before(function(done) {
        request(util.url + "/jobs", function(err, response, body) {
            if (err) done(err);
            jobs = JSON.parse(body).data.jobs;
            done();
        });
    });

    it("can start every job it lists", function(done) {
        promises = [];
        for (var i = 0; i < jobs.length; i++) {
            if (util.isDiscreteTarget(jobs[i].algorithm_name)) {
                promises.push(util.wrap("discrete", jobs[i].job_id));
            }

            if (util.isContinuousTarget(jobs[i].algorithm_name)) {
                promises.push(util.wrap("continuous", jobs[i].job_id));
            }

            if (util.isLifetimeRegressionTarget(jobs[i].algorithm_name)) {
                promises.push(util.wrap("lifetime", jobs[i].job_id));
            }
        }
        Promise.all(promises).then(() => {
            done();
        });
    });

    it("informs the user of a malformed request", (done) => {
        data = {
            "job_id": jobs[0].job_id,
            "training_data": {
                "id": "1",
                "project_name": "project1"
            },
            "output_directory_path": "/var/tmp",
            "input_columns": classifierColumns,
            "output_columns": [{
                "column_index": classifierTypes.length - 1,
                "column_type": classifierTypes[classifierTypes.length - 1]
            }],
            "parameters": {
                "not_a_parameter": "yikes"
            }
        };
        request_obj = {
            url: util.url + "/models",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer 12345"
            },
            body: JSON.stringify(data)
        };
        request.post(request_obj, (err, response, body) => {
            if (err) done(err);
            expect(response.statusCode).to.equal(400);
            body = JSON.parse(body);
            expect(body.error).to.be.a("string");
            expect(body.error_description).to.be.a("string");
            expect(body.user_message).to.be.a("string");
            done();
        });
    });

    it("does not permit a request without necessary authorisation", (done) => {
        data = {
            "job_id": jobs[0].job_id,
            "training_data": {
                "id": "1",
                "project_name": "project1"
            },
            "output_directory_path": "/var/tmp",
            "input_columns": classifierColumns,
            "output_columns": [{
                "column_index": classifierTypes.length - 1,
                "column_type": classifierTypes[classifierTypes.length - 1]
            }]
        };
        request_obj = {
            url: util.url + "/models",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Unauthorized"
            },
            body: JSON.stringify(data)
        };
        request.post(request_obj, (err, response, body) => {
            if (err) done(err);
            expect(response.statusCode).to.equal(401);
            body = JSON.parse(body);
            expect(body.error).to.be.a("string");
            expect(body.error_description).to.be.a("string");
            expect(body.user_message).to.be.a("string");
            done();
        });
    });

    it("does not permit a request without a job id", (done) => {
        data = {
            "training_data": {
                "id": "1",
                "project_name": "project1"
            },
            "output_directory_path": "/var/tmp",
            "input_columns": classifierColumns,
            "output_columns": [{
                "column_index": classifierTypes.length - 1,
                "column_type": classifierTypes[classifierTypes.length - 1]
            }]
        };
        request_obj = {
            url: util.url + "/models",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer 12345"
            },
            body: JSON.stringify(data)
        };
        request.post(request_obj, (err, response, body) => {
            if (err) done(err);
            expect(response.statusCode).to.equal(400);
            body = JSON.parse(body);
            expect(body.detail).to.be.a("string");
            expect(body.status).to.be.a("number");
            expect(body.title).to.be.a("string");
            expect(body.type).to.be.a("string");
            done();
        });
    });

    it("does not permit a request without training data", (done) => {
        data = {
            "job_id": jobs[0].job_id,
            "output_directory_path": "/var/tmp",
            "input_columns": classifierColumns,
            "output_columns": [{
                "column_index": classifierTypes.length - 1,
                "column_type": classifierTypes[classifierTypes.length - 1]
            }]
        };
        request_obj = {
            url: util.url + "/models",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer 12345"
            },
            body: JSON.stringify(data)
        };
        request.post(request_obj, (err, response, body) => {
            if (err) done(err);
            expect(response.statusCode).to.equal(400);
            body = JSON.parse(body);
            expect(body.detail).to.be.a("string");
            expect(body.status).to.be.a("number");
            expect(body.title).to.be.a("string");
            expect(body.type).to.be.a("string");
            done();
        });
    });

    it("does not permit a request without an output directory path", (done) => {
        data = {
            "job_id": jobs[0].job_id,
            "training_data": {
                "id": "1",
                "project_name": "project1"
            },
            "input_columns": classifierColumns,
            "output_columns": [{
                "column_index": classifierTypes.length - 1,
                "column_type": classifierTypes[classifierTypes.length - 1]
            }]
        };
        request_obj = {
            url: util.url + "/models",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer 12345"
            },
            body: JSON.stringify(data)
        };
        request.post(request_obj, (err, response, body) => {
            if (err) done(err);
            expect(response.statusCode).to.equal(400);
            body = JSON.parse(body);
            expect(body.detail).to.be.a("string");
            expect(body.status).to.be.a("number");
            expect(body.title).to.be.a("string");
            expect(body.type).to.be.a("string");
            done();
        });
    });

    it("does not permit a request without input columns", (done) => {
        data = {
            "job_id": jobs[0].job_id,
            "training_data": {
                "id": "1",
                "project_name": "project1"
            },
            "output_directory_path": "/var/tmp",
            "output_columns": [{
                "column_index": classifierTypes.length - 1,
                "column_type": classifierTypes[classifierTypes.length - 1]
            }]
        };
        request_obj = {
            url: util.url + "/models",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer 12345"
            },
            body: JSON.stringify(data)
        };
        request.post(request_obj, (err, response, body) => {
            if (err) done(err);
            expect(response.statusCode).to.equal(400);
            body = JSON.parse(body);
            expect(body.detail).to.be.a("string");
            expect(body.status).to.be.a("number");
            expect(body.title).to.be.a("string");
            expect(body.type).to.be.a("string");
            done();
        });
    });

    it("does not permit a request without output columns", (done) => {
        data = {
            "job_id": jobs[0].job_id,
            "training_data": {
                "id": "1",
                "project_name": "project1"
            },
            "output_directory_path": "/var/tmp",
            "input_columns": classifierColumns
        };
        request_obj = {
            url: util.url + "/models",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer 12345"
            },
            body: JSON.stringify(data)
        };
        request.post(request_obj, (err, response, body) => {
            if (err) done(err);
            expect(response.statusCode).to.equal(400);
            body = JSON.parse(body);
            expect(body.detail).to.be.a("string");
            expect(body.status).to.be.a("number");
            expect(body.title).to.be.a("string");
            expect(body.type).to.be.a("string");
            done();
        });
    });
});
