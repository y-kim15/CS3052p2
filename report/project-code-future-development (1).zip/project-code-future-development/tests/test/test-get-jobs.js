var expect = require("chai").expect;
var request = require("request");
var util = require("../util.js");

describe("get available jobs", function() {
    it("can request the available models", function(done){
        request(util.url + "/jobs", function(err, response, body) {
            expect(response.statusCode).to.equal(200);
            body = JSON.parse(body);
            expect(body.data.jobs).to.be.an("array");
            for (var i = 0; i < body.data.jobs.length; i++) {
                expect(body.data.jobs[i].job_id).to.be.a("string");
                expect(body.data.jobs[i].data_type).to.be.a("string");
                expect(body.data.jobs[i].algorithm_name).to.be.a("string");
                expect(body.data.jobs[i].partial_training_support).to.be.a("boolean");
                expect(body.data.jobs[i].job_description).to.be.a("string");
                expect(body.data.jobs[i].parameters).to.be.an("array");
            }
            done();
        });
    });
});

