var expect = require("chai").expect;
var request = require("request");
var util = require("../util.js");

//////////
// TESTS
//////////

describe("request to get available transformers", () => {
    it("can request the available transformers", (done) => {
        request(util.url + "/estimators", (err, response, body) => {
            if (err) done(err);
            expect(response.statusCode).to.equal(200);
            body = JSON.parse(body);
            expect(body.data.jobs).to.be.an("array");
            for (var i = 0; i < body.data.jobs.length; i++) {
                expect(body.data.jobs[i].job_id).to.be.a("string");
                expect(body.data.jobs[i].transformer_name).to.be.a("string");
                expect(body.data.jobs[i].job_description).to.be.a("string");
                expect(body.data.jobs[i].parameters).to.be.an("array");
                for (var j = 0; j < body.data.jobs[i].parameters.length; j++) {
                    expect(body.data.jobs[i].parameters[j].name).to.be.a("string");
                    expect(body.data.jobs[i].parameters[j].type).to.be.a("string");
                    expect(body.data.jobs[i].parameters[j].value).to.be.a("string");
                    expect(body.data.jobs[i].parameters[j].info).to.be.a("string");
                }
            }
            done();
        });
    });
});

